from random import randint as rand
import pygame as pg
pg.init() # do this before any classes or any code or any thing and before you have kids
screen = pg.display.set_mode((1000, 1000)) # (size_x, size_y) in pixels (px)
grid = []
flags = []
tej = 0
num_squares = 0
num_unflagged = 2
background = [[0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
              [0, 0, 0, 1, 1, 0, 1, 1, 0, 0],
              [0, 0, 1, 1, 1, 0, 0, 0, 1, 0],
              [0, 1, 1, 1, 0, 0, 0, 0, 1, 0],
              [0, 1, 1, 0, 1, 0, 0, 0, 1, 0],
              [0, 0, 0, 0, 0, 1, 0, 0, 1, 0],
              [0, 0, 1, 1, 1, 0, 1, 1, 0, 0],
              [0, 1, 1, 1, 0, 1, 1, 1, 0, 0],
              [1, 1, 1, 0, 0, 0, 0, 0, 1, 0],
              [1, 1, 0, 0, 0, 0, 0, 0, 0, 1]]
mineFont = pg.font.SysFont("arial", 40)
num_mines = 0
num_flags = 0
for y in range(10):
    grid.append([])
    for x in range(10):
        num = 0
        if num == 2: num = 0
        grid[y].append(num)
for mines in range(25):
    e = rand(0,9)
    l = rand(0,9)
    grid[e][l] = 1
print(grid)
for y in range(10):
    flags.append([])
    for x in range(10):
        num = 0
        flags[y].append(num)
# set spawn
x = rand(0, 9)
y = rand(0, 9)

for i in range(30):
    if rand(0, 1) == 0: x = max(0, min(9, x + rand(-1, 1)))
    else: y = max(0, min(9, y + rand(-1, 1)))
    grid[y][x] = 2

def getAdjacentMines(pos):
    if grid[pos[1]][pos[0]] == 1: return None
    adjMines = 0
    for y in range(-1, 2):
        if (pos[1] == 0 and y == -1) or (pos[1] == 9 and y == 1): continue
        for x in range(-1, 2):
            if (pos[0] == 0 and x == -1) or (pos[0] == 9 and x == 1): continue
            if pos[1]+y > len(grid)-1 or pos[0]+x > len(grid[y])-1: continue
            if grid[pos[1]+y][pos[0]+x] == 1: adjMines += 1

    return adjMines

def drawGrid():
    for y in range(10):
        for x in range(10):
            pg.draw.rect(screen, (255, 255, 255), (x*100, y*100, 100, 100))
            if x % 2 == 0 and y % 2 == 0:
                pg.draw.rect(screen, (125, 255, 125), (x*100+5, y*100+5, 90, 90), border_radius=5)
            elif x % 2 == 1 and y % 2 == 1:
                pg.draw.rect(screen, (125, 255, 125), (x*100+5, y*100+5, 90, 90), border_radius = 5)
            else:
                pg.draw.rect(screen, (0, 255, 0), (x*100+5, y*100+5, 90, 90), border_radius = 5)
            #if grid[y][x] == 2 and flags[y][x] != 1:
            #    if background[y][x] == 1:
            #        pg.draw.rect(screen, (255, 255, 0), (x*100+5, y*100+5, 90, 90), border_radius=5)
            #    else:
            #        pg.draw.rect(screen, (255, 0, 0), (x*100+5, y*100+5, 90, 90), border_radius=5)
            if grid[y][x] == 2 and flags[y][x] != 1:
                pg.draw.rect(screen, (255, 125, 0), (x*100+5, y*100+5, 90, 90), border_radius=5)
                adjMines = getAdjacentMines((x, y))
                if adjMines != None: screen.blit(mineFont.render(str(adjMines), True, (0, 0, 0)), (x*100+50, y*100+25))
            if flags[y][x] == 1:
                pg.draw.rect(screen, (0, 0, 255), (x*100+5, y*100+5, 90, 90), border_radius=5)
def lose_screen():
    for y in range(0,9):
        for x in range(0,9):
            if grid[y][x] == 1 and flags[y][x] != 1:
                pg.draw.rect(screen, (255, 0, 255), (x*100+5, y*100+5, 90, 90), border_radius=5)

while True: # game loop
    screen.fill((0, 0, 0)) # clear the screen to black
    # event loop
    for event in pg.event.get(): # must have this so window is not (not responding)
        if event.type == pg.QUIT: # must have this so window is not (not responding)
            pg.quit() # must have this so window is not (not responding)
            exit() # must have this so window is not (not responding)
        if event.type == pg.MOUSEBUTTONDOWN:
            if event.button == 1:
                # get the position of the cursor on the grid
                cx, cy = pg.mouse.get_pos()
                cx = int(round((cx-50) / 100, 0))
                cy = int(round((cy-50) / 100, 0))
                if flags[cy][cx] != 1 and grid[cy][cx] == 1:
                    screen.fill((255,0,0))
                    print("You blew up.")
                    #lose_screen()
                    pg.quit()
                    exit()
                if flags[cy][cx] != 1:
                    grid[cy][cx] = 2

        if event.type == pg.MOUSEBUTTONDOWN:
            if event.button == 3:
                # get the position of the cursor on the grid
                cx, cy = pg.mouse.get_pos()
                cx = int(round((cx-50) / 100, 0))
                cy = int(round((cy-50) / 100, 0))
                if flags[cy][cx] == 0:
                    flags[cy][cx] = 1
                else:
                    flags[cy][cx] = 0


    #pg.draw.rect(screen, (255, 255, 0), (200, 200, 200, 200)) # screen, color (rgb), (x, y, width, height) ||||| draws a rectagnle

    drawGrid()

    pg.display.flip() # updates (draws) everything on the display