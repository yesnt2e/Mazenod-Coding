from random import randint as rand
import pygame as pg
pg.init() # do this before any classes or any code or any thing and before you have kids
i = int(input("Mines: "))
screen = pg.display.set_mode((1000, 1000)) # (size_x, size_y) in pixels (px)
grid = []
flags = []
mineFont = pg.font.SysFont("arial", 10)
num_mines = 0
num_flags = 0
for y in range(100):
    grid.append([])
    for x in range(100):
        if num_mines<i:
            num = rand(0, 2)
            if num == 2: num = 0
            if num == 1: num_mines+=1
        else: num = 0
        grid[y].append(num)
print(num_mines)
for y in range(100):
    flags.append([])
    for x in range(100):
        num = 0
        flags[y].append(num)
# set spawn
x = rand(0, 99)
y = rand(0, 99)

for i in range(3000):
    if rand(0, 1) == 0: x = max(0, min(9, x + rand(-1, 1)))
    else: y = max(0, min(9, y + rand(-1, 1)))
    grid[y][x] = 2

def getAdjacentMines(pos):
    if grid[pos[1]][pos[0]] == 1: return None
    adjMines = 0
    for y in range(-1, 2):
        for x in range(-1, 2):
            if pos[1]+y > len(grid)-1 or pos[0]+x > len(grid[y])-1: continue
            if grid[pos[1]+y][pos[0]+x] == 1: adjMines += 1

    return adjMines

def drawGrid():
    for y in range(100):
        for x in range(100):
            pg.draw.rect(screen, (0, 0, 0), (x*10, y*10, 10000, 10000))
            pg.draw.rect(screen, (255, 255, 255), (x*10+0.5, y*10+0.5, 9, 9), border_radius=1)
            if grid[y][x] == 2:
                adjMines = getAdjacentMines((x, y))
                if adjMines == 1:
                    pg.draw.rect(screen, (0, 255, 0), (x*10+0.5, y*10+0.5, 9, 9), border_radius=1)
                if adjMines == 2:
                    pg.draw.rect(screen, (255, 0, 0), (x*10+0.5, y*10+0.5, 9, 9), border_radius=1)
                if adjMines == 3:
                    pg.draw.rect(screen, (255, 0, 255), (x*10+0.5, y*10+0.5, 9, 9), border_radius=1)
                if adjMines == 4:
                    pg.draw.rect(screen, (255, 255, 0), (x*10+0.5, y*10+0.5, 9, 9), border_radius=1)
                if adjMines == 5:
                    pg.draw.rect(screen, (0, 255, 255), (x*10+0.5, y*10+0.5, 9, 9), border_radius=1)
                if adjMines == 6:
                    pg.draw.rect(screen, (255, 125, 0), (x*10+0.5, y*10+0.5, 9, 9), border_radius=1)
                if adjMines == 7:
                    pg.draw.rect(screen, (125, 255, 0), (x*10+0.5, y*10+0.5, 9, 9), border_radius=1)
                if adjMines == 8:
                    pg.draw.rect(screen, (0, 125, 255), (x*10+0.5, y*10+0.5, 9, 9), border_radius=1)
                if adjMines == 0:
                    pg.draw.rect(screen, (255, 125, 125), (x*10+0.5, y*10+0.5, 9, 9), border_radius=1)
            if flags[y][x] == 1:
                pg.draw.rect(screen, (0, 0, 255), (x*10+0.5, y*10+0.5, 9, 9), border_radius=1)

while True: # game loop
    screen.fill((0, 0, 0)) # clear the screen to black
    # event loop
    for event in pg.event.get(): # must have this so window is not (not responding)
        if event.type == pg.QUIT: # must have this so window is not (not responding)
            pg.quit() # must have this so window is not (not responding)
            exit() # must have this so window is not (not responding)
        if event.type == pg.MOUSEBUTTONDOWN:
            if event.button == 1:
                # get the position of the cursor on the grid
                cx, cy = pg.mouse.get_pos()
                cx = int(round((cx-5) / 10, 0))
                cy = int(round((cy-5) / 10, 0))
                if flags[cy][cx] != 1:
                    if grid[cy][cx] == 1:
                        screen.fill((255,0,0))
                        print("You blew up.")
                        pg.quit()
                        exit()
                if flags[cy][cx] != 1:
                    grid[cy][cx] = 2
                    if getAdjacentMines((cy,cx)) == None:
                        x = cx
                        y = cy
                        for i in range(rand(100, 3000)):
                            if rand(0, 1) == 0: x = max(0, min(99, x + rand(0, 1)))
                            else: y = max(0, min(99, y + rand(-1, 1)))
                            if grid[y][x] != 1:
                                grid[y][x] = 2

        if event.type == pg.MOUSEBUTTONDOWN:
            if event.button == 3:
                # get the position of the cursor on the grid
                cx, cy = pg.mouse.get_pos()
                cx = int(round((cx-5) / 10, 0))
                cy = int(round((cy-5) / 10, 0))
                if flags[cy][cx] == 1:
                    flags[cy][cx] = 0
                else:
                    flags[cy][cx] = 1


    #pg.draw.rect(screen, (255, 255, 0), (200, 200, 200, 200)) # screen, color (rgb), (x, y, width, height) ||||| draws a rectagnle

    drawGrid()

    pg.display.flip() # updates (draws) everything on the display