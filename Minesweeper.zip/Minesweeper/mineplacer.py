from random import randint as rand
import pygame as pg
import keyboard
pg.init() # do this before any classes or any code or any thing and before you have kids
i = int(input("Mines: "))
screen = pg.display.set_mode((1000, 1000)) # (size_x, size_y) in pixels (px)
grid = []
flags = [] 
num_squares = 0
num_unflagged = 2
background = [[0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
              [0, 0, 0, 1, 1, 0, 1, 1, 0, 0],
              [0, 0, 1, 1, 1, 0, 0, 0, 1, 0],
              [0, 1, 1, 1, 0, 0, 0, 0, 1, 0],
              [0, 1, 1, 0, 1, 0, 0, 0, 1, 0],
              [0, 0, 0, 0, 0, 1, 0, 0, 1, 0],
              [0, 0, 1, 1, 1, 0, 1, 1, 0, 0],
              [0, 1, 1, 1, 0, 1, 1, 1, 0, 0],
              [1, 1, 1, 0, 0, 0, 0, 0, 1, 0],
              [1, 1, 0, 0, 0, 0, 0, 0, 0, 1]]
mineFont = pg.font.SysFont("arial", 40)
num_mines = 0
num_flags = 0
for y in range(10):
    grid.append([])
    for x in range(10):
        grid[y].append(0)
for y in range(10):
    flags.append([])
    for x in range(10):
        num = 0
        flags[y].append(num)

def drawGrid():
    for y in range(10):
        for x in range(10):
            pg.draw.rect(screen, (255, 255, 255), (x*100, y*100, 100, 100))
            if x % 2 == 0 and y % 2 == 0:
                pg.draw.rect(screen, (125, 255, 125), (x*100+5, y*100+5, 90, 90), border_radius=5)
            elif x % 2 == 1 and y % 2 == 1:
                pg.draw.rect(screen, (125, 255, 125), (x*100+5, y*100+5, 90, 90), border_radius = 5)
            else:
                pg.draw.rect(screen, (0, 255, 0), (x*100+5, y*100+5, 90, 90), border_radius = 5)
            if grid[y][x] == 2 and flags[y][x] != 1:
                if background[y][x] == 1:
                    pg.draw.rect(screen, (255, 255, 0), (x*100+5, y*100+5, 90, 90), border_radius=5)
                else:
                    pg.draw.rect(screen, (255, 0, 0), (x*100+5, y*100+5, 90, 90), border_radius=5)
            if flags[y][x] == 1:
                screen.blit(mineFont.render("<|", True, (255, 0, 0)), (x*100+50, y*100+25))
def lose_screen():
    for y in range(0,9):
        for x in range(0,9):
            if grid[y][x] == 1 and flags[y][x] != 1:
                pg.draw.rect(screen, (255, 0, 255), (x*100+5, y*100+5, 90, 90), border_radius=5)

while True: # game loop
    screen.fill((0, 0, 0)) # clear the screen to black
    # event loop
    for event in pg.event.get(): # must have this so window is not (not responding)
        if event.type == pg.QUIT: # must have this so window is not (not responding)
            pg.quit() # must have this so window is not (not responding)
            exit() # must have this so window is not (not responding)
        if event.type == pg.MOUSEBUTTONDOWN:
            if event.button == 1:
                # get the position of the cursor on the grid
                cx, cy = pg.mouse.get_pos()
                cx = int(round((cx-50) / 100, 0))
                cy = int(round((cy-50) / 100, 0))
                flags[cy][cx] = 1
        if keyboard.is_pressed("s"):
            with open("Flags.txt", "w") as f:
                f.write(str(flags))
            with open("Mines.txt", "w") as m:
                m.write(str(grid))
        for y in range(0,9):
            for x in range(0,9):
                if grid[y][x] == 1 and flags[y][x] == 0:
                    num_squares += 1
                elif grid[y][x] == 2:
                    num_squares += 1
            if num_squares == 100:
                print("You Win")
                pg.quit()
                exit()


    #pg.draw.rect(screen, (255, 255, 0), (200, 200, 200, 200)) # screen, color (rgb), (x, y, width, height) ||||| draws a rectagnle

    drawGrid()

    pg.display.flip() # updates (draws) everything on the display