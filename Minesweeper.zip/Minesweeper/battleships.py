from random import randint as rand
import pygame as pg

pg.init() # do this before any classes or any code or any thing and before you have kids

screen = pg.display.set_mode((1000, 1000)) # (size_x, size_y) in pixels (px)
grid = [[0, 0, 1, 1, 1, 1, 1, 0, 0, 0],
        [0, 1, 0, 1, 1, 1, 0, 0, 0, 0],
        [1, 1, 0, 0, 0, 0, 0, 0, 0, 0],
        [1, 0, 0, 0, 0, 0, 1, 1, 1, 0],
        [1, 0, 1, 0, 0, 0, 0, 0, 0, 0],
        [1, 0, 1, 1, 1, 1, 0, 0, 0, 0],
        [0, 0, 1, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]]
user_grid = [[1, 0, 0, 0, 0, 0, 0, 0, 0, 0],
             [1, 1, 1, 1, 1, 1, 0, 0, 0, 0],
             [1, 0, 1, 1, 0, 0, 0, 0, 0, 0],
             [1, 0, 0, 1, 1, 1, 0, 0, 0, 0],
             [0, 0, 1, 1, 1, 0, 0, 0, 0, 1],
             [1, 1, 1, 0, 0, 0, 0, 0, 0, 1],
             [0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
             [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]]
enemy_hits = 0
enemy_boats = 0
hits = 0
guesses = [[0 for x in range(10)] for y in range(10)]
user_guesses = [[0 for x in range(10)] for y in range(10)]
mineFont = pg.font.SysFont("arial", 40)
# set spawn

def drawGrid():
    for y in range(10):
        for x in range(10):
            pg.draw.rect(screen, (0, 0, 0), (x*100, y*100, 100, 100))
            pg.draw.rect(screen, (255, 255, 255), (x*100+5, y*100+5, 90, 90), border_radius=5)
            if grid[y][x] == 4:
                pg.draw.rect(screen, (255, 0, 0), (x*100+5, y*100+5, 90, 90), border_radius=5)
            elif guesses[y][x] == 1 and not grid[y][x] == 1:
                pg.draw.rect(screen, (0, 255, 0), (x*100+5, y*100+5, 90, 90), border_radius=5)

while True: # game loop
    screen.fill((0, 0, 0)) # clear the screen to black
    # event loop
    for event in pg.event.get(): # must have this so window is not (not responding)
        if event.type == pg.QUIT: # must have this so window is not (not responding)
            pg.quit() # must have this so window is not (not responding)
            exit() # must have this so window is not (not responding)
        if event.type == pg.MOUSEBUTTONDOWN:
            if event.button == 1:
                # get the position of the cursor on the grid
                cx, cy = pg.mouse.get_pos()
                cx = int(round((cx-50) / 100, 0))
                cy = int(round((cy-50) / 100, 0))
                if grid[cy][cx] == 0:
                    grid[cy][cx] = 2
                    guesses[cy][cx] = 1
                if grid[cy][cx] == 1:
                    grid[cy][cx] = 4
                    hits += 1
                dx = rand(0,9)
                dy = rand(0,9)
                if user_grid[dy][dx] == 1 and user_guesses == 0:
                    print("Hit by enemy!")
                    enemy_hits += 1
                elif user_guesses[dy][dx] == 1:
                    for y in range(0,9):
                        for x in range(0,9):
                            if user_grid[y][x] == 1 and user_guesses == 0:
                                enemy_boats += 1
                    if enemy_boats < 23:
                        dx = rand(0,9)
                        dy = rand(0,9)
                    elif enemy_boats == 23 and hits < 23:
                        print("Loser")
                    elif enemy_boats < 23 and hits == 23:
                        print("Winner")
    drawGrid()

    pg.display.flip() # updates (draws) everything on the display